<?php // Include confi.php
session_start();
include_once('config.php');
$id = $_SESSION['mail'];
if($id == ''){
header('location:login.php');
}
else{
	
if(isset($_GET['title'])){
	$title=$_GET['title'];
	$query = " DELETE FROM documents WHERE  user_name = '$id' AND doc_title = '$title' "; 
	$result = mysqli_query($con,$query);
	
}
echo '<script>alert("Document Deleted");</script>';
header("refresh:0;url=delete.php");
mysqli_close($con);
}

 ?>