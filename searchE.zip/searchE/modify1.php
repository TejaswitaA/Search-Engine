
 <?php // Include confi.php
session_start();
include_once('config.php');
 $id = $_SESSION['mail'];

if($id == ''){
header('location:login.php');
}
else{
	if(isset($_GET['title'])){
	$title=$_GET['title'];
	$query = " SELECT * FROM documents WHERE  user_name = '$id' AND doc_title = '$title' "; 
	$result = mysqli_query($con,$query);
		$_SESSION["titlee"]=$title;
}
	?>
 <!DOCTYPE HTML>
<html>

<head>
  <title>log_in</title>
  <link rel="stylesheet" type="text/css" href="style.css" title="style" />
</head>
<script>
function validateform(){
			
		var x = document.getElementById("subject").value;
		var re=/^[\w ]+$/;
		if (x == null || x == "") {
        		alert(" subject must be filled out");
				myForm2.name.focus();

        		return false;
   			}
		if(!re.test(x))
			{
				alert("Error:subject contains INVALID characters");
				myForm2.name.focus();
				return false;
			}
			 x = document.getElementById("author").value;
		if (x == null || x == "") {
        		alert(" author must be filled out");
				myForm2.name.focus();

        		return false;
   			}
		if(!re.test(x))
			{
				alert("Error:author contains INVALID characters");
				myForm2.name.focus();
				return false;
			}
		x = document.getElementById("title").value;
		if (x == null || x == "") {
        		alert(" title must be filled out");
				myForm2.title.focus();

        		return false;
   			}
		x = document.getElementById("desc").value;
		if (x == null || x == "") {
        		alert(" description must be filled out");
				myForm2.desc.focus();

        		return false;
   			}


		var z=myForm2.file.value;
		if (z == null || z == "") {
        		alert(" document must be uploaded");
				myForm2.file.focus();

        		return false;
   			}

		var r = confirm("Upload Document?");
		if (r == true) {alert("Document Uploaded");
		return true;
		} else {
		return false;
	
			
			return true;
		
			
			
}
	</script>


<body>
	   <table><tr><td><div align="left">
				<form action = 'admin.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'Back' class="submit" >
				 </form>
		</div></td>
	   <td><div align="right">
				<form action = 'logout.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'LogOut' class="submit" >
				 </form>
		</div></td></tr></table>
		<h3 align="left"> Logged In as <?php echo $id;?></h3>
	<div class="login" ><center>
	<h2 style="color:white; background-color:royalblue">MODIFY</h2>
	
	
	<?php 
  
while( $runrows = mysqli_fetch_assoc( $result ) ) { 
$title = $runrows ['doc_title'];
 $desc = $runrows ['description'];
 $url = $runrows ['doc_url'];
$type= $runrows ['doc_type'];?>

<form method="post" class="form_settings" name="myForm2" onsubmit="return validateform()" action="modify2.php" enctype="multipart/form-data">
		<p style="margin-left:45px;text-align:left; color:black">Document Type:</p>
		<input type="text"  id="subject" name="category" value ="<?php echo "".$runrows['doc_type'].""; ?>" required="required" maxlength="50" readonly /></br></br>
		<input type="text"  id="subject" name="subject" placeholder="<?php echo "".$runrows['subject'].""; ?>" required="required" maxlength="50"/><br><br>
		<input type="text"  id="title" name="title" value ="<?php echo "".$runrows['doc_title'].""; ?>" required="required" maxlength="50" readonly /><br><br>
<textarea rows="3" cols="75" name="desc" id="desc" placeholder="<?php echo "".$runrows['description'].""; ?>" maxlength="100"></textarea>		
<input type="text"  id="author" name="author" placeholder="<?php echo "".$runrows['author'].""; ?>" required="required" maxlength="100" /><br><br>
				<p style="margin-left:45px;text-align:left; color:black">Upload document here:</p>
		<input type="file" name="file" id="file" accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint,
text/plain, application/pdf ,application/ppt,application/doc,image/jpeg,image/png,image/tiff,image/bmp,image/gif" />

        <input type="submit"  class="submit1" value="MODIFY" name="submit" >
    </form>
<?php
}
}
mysqli_close($con);
?>
</center>
</div>
</body>
</html>