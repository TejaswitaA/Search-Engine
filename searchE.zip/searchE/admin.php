<?php
session_start();
include_once('config.php');
$con = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("searche",$con) or die("Couldn't connect to the database");

error_reporting(0);
$id = $_SESSION['mail'];

if($id == ''){
header('location:login.php');
}


?>
<!DOCTYPE HTML>
<html>

<head>
  <title>log_in</title>
  <link rel="stylesheet" type="text/css" href="style.css" title="style" />
</head>



<body>
	   <table><tr><td><div align="left">
				<form action = 'logout.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'Back' class="submit" >
				 </form>
		</div></td>
	   <td><div align="right">
				<form action = 'logout.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'LogOut' class="submit" >
				 </form>
		</div></td></tr></table>
		<div class="login" ><center>
		<h2 style="color:white; background-color:royalblue">WELCOME</h2>
		<div>
				<form action = 'upload1.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'UPLOAD' class="submit" >
				 </form>
		</div>
		<br/><br/>
		<div>
				<form action = 'modify.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'MODIFY' class="submit" >
				 </form>
		</div>
		<br/><br/>
		<div>
				<form action = 'delete.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'DELETE' class="submit" >
				 </form>
		</div>
</center>
</div>
</body>
</html>
