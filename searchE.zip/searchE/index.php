<?php 
session_start();
include_once('config.php');
session_unset();
session_destroy();
session_start();
?>
<html>
       <head>
             <title> My search engine </title>
			   <link rel="stylesheet" type="text/css" href="style.css" />
			  
			   <style>
				.docs {
				 width: 500px;
				 height: 400px;
				 overflow: scroll; 
				}
			   </style>
			    </head>
<script>
function find(){
/*var xhttp = jQuery.ajax({
    url: "find.php",
    type: "POST",
    data: {variable_name: search}
});
xhttp.always(function(){
    $('.docs').append(xhttp.responseText);
        //$('.className').html(ajax_control.responseText);
        //$('.className').val(ajax_control.responseText); // if this is a textarea
}); */


var string=document.getElementById("search").value;
		if ( string== null || string == "") {
        		alert("enter keywords");
				myForm2.search.focus();

        		return ;
   			}
			        	
			
			 var xhttp=null;
			 xhttp = new XMLHttpRequest();
			 if(xhttp){      
				xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				document.getElementById("docs").innerHTML =this.responseText;
				 $('.docs').append(this.responseText);
				
			}
		};
  xhttp.open("GET", "find.php?q="+string, true);
  xhttp.send();   

			 }else {
				 alert("error");
			 }
}
</script>
       <body>
	   <div align="right">
				<form action = 'login.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'Login' class="submit" >
				 </form>
		</div>
	   <div id ="middle" align="center">
				<form  class="frm"  >
                           <h1 id="1"> SEARCH HERE </h1 >
                           <input type = 'text' maxlength='90' name = 'search' id='search'/ >
<button type = 'button' name = 'submit'class="submit"onclick="find()" >Search</button>
    </form >
					<form  class="frm" action="advance.php" >
					<input type="submit" name = 'submit'class="submit" value="Advanced">
					</form>

				 <div id = "docs" align="left">content will appear here </div>

			 </div>
       </body >
</html > 




