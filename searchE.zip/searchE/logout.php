<?php
	session_start();
	// Create connection
	$con = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

	mysql_select_db("searche",$con) or die("Couldn't connect to the database");
	// echo "Successfully connected to the server and successfully connected to the database blog";

	error_reporting(0);
    session_destroy();
    header("location:index.php");
?>