
 <?php // Include confi.php
session_start();
include_once('config.php');
 $id = $_SESSION['mail'];

if($id == ''){
header('location:login.php');
}
else{

	$query = " SELECT * FROM documents WHERE  user_name = '$id' "; 
	 $result = mysqli_query($con,$query);
	?>
 <!DOCTYPE HTML>
<html>

<head>
  <title>log_in</title>
  <link rel="stylesheet" type="text/css" href="style.css" title="style" />
</head>


<body>
	   <table><tr><td><div align="left">
				<form action = 'admin.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'Back' class="submit" >
				 </form>
		</div></td>
	   <td><div align="right">
				<form action = 'logout.php' method = 'post' class="frm" >
					 <input type = 'submit'  name = 'submit' value = 'LogOut' class="submit" >
				 </form>
		</div></td></tr></table>
		<h3 align="left"> Logged In as <?php echo $id;?></h3>
	<div class="login" ><center>
	<h2 style="color:white; background-color:royalblue">MODIFY</h2>
	
	
	<?php 
	 //$result = mysql_query($query);
   $num= mysqli_num_rows($result);
	if($num==0){
	$output= "<p>Sorry, there is no document uploaded by you</p>"; }
else { $output= "<p>$num results found !</p>"; 
while( $runrows = mysqli_fetch_assoc( $result ) ) { 
$title = $runrows ['doc_title'];
 $desc = $runrows ['description'];
 $url = $runrows ['doc_url'];
$type= $runrows ['doc_type'];
if($type!="image"){
$output.= "<p><a href='modify1.php?title=".$runrows['doc_title']."'> <b> Modify $title file </b> </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='$url'> <b> open $title file </b> </a> <br> $desc  </p> "; 
}
else $output.= "<p><a href='modify1.php?title=".$runrows['doc_title']."'> <b> Modify $title file </b> </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='$url'> <b> open $title file </b> </a><br><img src='".$url."' style='max-height:250px; width:auto'/> <br> $desc  </p> "; 

}
}
echo $output;
}
mysqli_close($con);
?>
</center>
</div>
</body>
</html>