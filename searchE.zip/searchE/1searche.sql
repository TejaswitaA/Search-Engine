-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2017 at 10:49 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `searche`
--

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `doc_id` int(11) NOT NULL,
  `doc_url` varchar(200) NOT NULL,
  `doc_title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `doc_type` varchar(50) NOT NULL,
  `creation_date` date NOT NULL,
  `subject` varchar(50) NOT NULL,
  `author` varchar(100) NOT NULL,
  `content` text,
  `user_name` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`doc_id`, `doc_url`, `doc_title`, `description`, `doc_type`, `creation_date`, `subject`, `author`, `content`, `user_name`) VALUES
(12, 'uploads/Book1.xlsx', 'Datas', 'Data information about transport services and vehicles.', 'doc', '2017-03-22', 'Excel', 'Transport dept', 'Excel Transport dept doc uploads/Book1.xlsx Datas Data information about transport services and vehicles. Invalid File Type', 'tejas@gmail.com'),
(13, 'uploads/NCERT.pdf', 'History 6', 'NCERT History book 6 Standard. Study for exam, test.', 'pdf', '2017-03-22', 'Book', 'NCERT', 'Book NCERT pdf uploads/NCERT.pdf History 6 NCERT History book 6 Standard. Study for exam, test. NCERT\n \n \n \nTejaswita Atal\n \n|\n \n[Course Title]\n \n|\n \n[Date]\n \n[Report Title]\n \n[REPORT SUBTITLE]\n \nPAGE \n1\n \nGet Started Right Away\n \nWhen you click this placeholder text, just start typing to replace it all. But donâ€™t do that just yet!\n \nThis placeholder includes tips to help \nyou quickly format your report and add other elements, such \nas a chart, diagram, or table of contents.  You might be amazed at how easy it is.\n \nMake It Gorgeous\n \nâˆ’\n \nNeed a heading? On the Home tab, in the Styles gallery, just click the heading style you \nwant. N\notice other styles in that gallery as well, such as for a quote or a numbered list.\n \nâˆ’\n \nYou might like the cool, blue ice pond on the cover page as much as we do, but if itâ€™s not \nideal for your report, right\n-\nclick it and then click Change Picture to add your o\nwn photo.\n \nâˆ’\n \nAdding a professional\n-\nquality graphic is a snap. In fact, when you add a chart or a SmartArt \ndiagram from the Insert tab, it automatically matches the look of your document.\n \n \nGive It That Finishing Touch\n \nNeed to add a table of contents or a bibl\niography? No sweat.\n \nADD A TABLE OF CONTE\nNTS\n \nIt couldnâ€™t be easier to add a table of contents to your report. On the Insert tab, click Cover Page to \nsee cover page designs that include a table of contents page \nâ€”\n \nlook for TOC. \n \nJust click to insert one of th\nese and youâ€™ll be prompted to update the TOC. When you do, text you \nformatted using Heading 1, Heading 2, and Heading 3 styles is automatically added. \n \nADD A BIBLIOGRAPHY\n \nOn the References tab, in the Citations & Bibliography group, click Insert Citation f\nor the option to \nadd sources and then place citations in the document. \n \nWhen youâ€™ve added all the citations you need for your report, on the References tab, click \nBibliography to insert a formatted bibliography in your choice of styles.\n \nAnd youâ€™re done. Ni\nce work!\n \n', 'tejas@gmail.com'),
(14, 'uploads/4_cpu scheduling.ppt', 'Operating system', 'Cpu Scheduling Algorithm learn study.', 'ppt', '2017-03-24', 'Data Science', 'Internet', 'Data Science Internet ppt uploads/4_cpu scheduling.ppt Operating system Cpu Scheduling Algorithm learn study. ', 'tejas@gmail.com'),
(15, 'uploads/news.txt', 'World', 'North Korea maintains readiness for nuclear test at any time: South Korea.\r\nSports', 'text', '2017-03-24', 'News', 'Times Of India', 'News Times Of India text uploads/news.txt World North Korea maintains readiness for nuclear test at any time: South Korea.\r\nSports North Korea maintains readiness for nuclear test at any time: South Korea\r\n\r\nReuters | Updated: Mar 24, 2017, 09.42 AM IST\r\nNorth Korea leader Kim Jong Un\r\n\r\nSEOUL: North Korea has maintained readiness to conduct a new nuclear test at any time, a South Korean military official said on Friday, amid a report of a possible test within days as Pyongyang defies international pressure.\r\nUS and South Korean military surveillance assets were closely monitoring the North''s Punggye-ri nuclear test site on the reclusive state''s east coast, said the official, who declined to be identified.\r\nSpeaking by telephone, the official also declined to comment on whether there were fresh signs pointing to an imminent test.\r\n"North Korea is ready to carry out a nuclear test at any time, depending on the leadership''s decision. We are keeping a close eye on its nuclear activities," the official said.\r\nSouth Korea has been aware that the North could move ahead with another test at any time since it conducted its last nuclear test in September.\r\nNorth Korea has conducted five nuclear tests and a series of missile launches, in defiance of UN sanctions, and is believed by experts and government officials to be working to develop nuclear-warhead missiles that could reach the United States.\r\nFox News in the United States reported on Thursday that the North was in the final stages of preparing for another nuclear test, possibly within the next few days. The network cited US officials with knowledge of recent intelligence.\r\nIt quoted one of the officials as saying as saying the test could come as early as the end of the month.\r\nThe Washington-based think tank 38 North said in February satellite imagery showed the North''s nuclear site continued low-level activity in a possible sign that it could conduct another test soon. However, it said it was unclear exactly when such a test might take place.\r\nThe South Korean military has said several times since the September test that Pyongyang was ready to conduct another nuclear blast at any time, and that a tunnel was available at the site to do so.', 'times@gmail.com'),
(11, 'uploads/TOIsports.docx', 'Sports', 'India v Australia, 4th Test: Dharamsalaâ€™s debut the stage for Indiaâ€™s biggest test', 'doc', '2017-03-22', 'News', 'Times Of India', 'News Times Of India doc uploads/TOIsports.docx Sports India v Australia, 4th Test: Dharamsalaâ€™s debut the stage for Indiaâ€™s biggest test \r\nTIMESOFINDIA.COMÂ |Â Mar 22, 2017, 08.54 AM IST\r\nHIGHLIGHTS\r\nThere is doubt over the participation of Virat Kohli, who injured his shoulder in the previous Test\r\nThe last time India got their hands on the Border-Gavaskar Trophy was in 2014-15\r\nThe conditions in Dharamsala should ideally aid swing\r\n\r\nThe HPCA Stadium in Dharamsala will make its Test debut when it hosts the fourth match of the Border-Gavaskar ...Â Read More\r\nNEW DELHI: The Himachal Pradesh Cricket Stadium, with the stunning backdrop of the Dhauladar mountain range, is the setting for a Test match with plenty at stake. The series is locked at 1-1 after three engrossing and intense - as well as acrimonious - matches on varied surfaces in Pune, Bangalore and Ranchi and victory in Dharamsala, hosting its first Test match, will decided the winner. India have not got their hands on the Border-Gavaskar Trophy since 2014-15, while Australia can take it home if they win and claim a memorable series victory.Five epic India v Australia series-deciding TestsFor Australia, there is the added incentive of avoiding defeat in this deciding Test so they can remain at second place in the ICC Test Championship ahead of the cut-off date of April 1, on which India is assured of finishing first and receiving a cash award of $1 million. Should Australia lose and South Africa win or draw with New Zealand in Hamilton, Steve Smith''s team will fall to third.Dharamsala Test: Are India fit for five-bowler ploy?If it seemed unthinkable that there would be a deadlock heading into the fourth and final Test of the series, it was becauseÂ Virat Kohli''s team was on a record unbeaten streak and Australia were in India after failing to win nine consecutive Tests in Asia. In Pune, Australia ransacked a jaded India inside three days to take the lead; on a sharp turner in Bangalore, India hit back with a win that Kohli termed ''the sweetest'' of his captaincy; a tussle in Ranchi ended in a draw, which has turned Dharamsala''s debut into the biggest match of India''s busiest home season ever.Shreyas Iyer called up as cover for Virat Kohli for 4th TestNew Zealand, England and Bangladesh were all beaten convincingly, but this is Australia. India know what beating them to regain the Border-Gavaskar Trophy will mean.Venue:Â HPCA Stadium, DharamsalaStart date:Â March 25, 2017Time:Â 09:30 ISTWeather:Â Partly cloudy with temperatures in the low to mid-20s\r\n', 'times@gmail.com'),
(1, 'uploads/food.txt', 'South Indian', 'Yummy and nutritious food.', 'text', '2017-03-31', 'Food', 'ChefK', 'Food ChefK  uploads/food.txt South Indian Yummy and nutritious food. ', 'chefK@gmail.com'),
(28, 'uploads/deccan_delight.jpg', 'South Indian', 'Idli Dosa', 'doc', '2017-03-31', 'Breakfast', 'Jack', 'Breakfast Jack doc uploads/deccan_delight.jpg South Indian Idli Dosa Invalid File Type', 'chefK@gmail.com'),
(16, 'uploads/chef4.jpg', 'Chef.com', 'Chef.com online food ordering website for yummy food.', 'image', '2017-03-26', 'Food', 'ChefK', 'Food ChefK image uploads/chef4.jpg Chef.com Chef.com online food ordering website for yummy food. ', 'chefK@gmail.com'),
(31, 'uploads/xslt1.pdf', 'pp', 'Books', 'pdf', '2017-03-31', 'title', 'ankitaa', 'title ankitaa pdf uploads/xslt1.pdf pp Books WhatmeansXSLT?\nXSL(eXtensibleStylesheetLanguage)consistsof\n\nXSL-T(Transformation)\n{\nprimarilydesignedfortransformingthestructureofanXMLdocument\n{\nW3CSpeci&#12;cation:\nhttp://www.w3c.org/TR/xslt\n\nXSL-FO(FormatingObjects)\n{\ndesignedforformattingXMLdocuments\n{\nW3CSpeci&#12;cation:\nhttp://www.w3c.org/TR/xsl\nXSLTorigin:DocumentStyleSemanticsandSpeci&#12;cationLanguage(DSSSL,pron.Dissel).\nDataConversion\nHowXMLdatacanbetransformedusingXSLT?(1/3)\n1\naconversionofXMLdataintoatreestructure,e.g.usinganXMLparserconformantto\n{\nDocumentObjectModel(DOM)\nhttp://www.w3.org/DOM/\n{\nSimpleApiforXML(SAX)\nhttp://www.megginson.com/SAX/sax.html\nTheplaceofXSLTintheXMLfamily(1/2)\n\nbasedonXMLInfoSetandNamespacesSpecs.\n\nStyling:XSLTvs.CSSCSScannot\n{\nreorderelementsfromtheXMLdocument.\n{\naddnewelements.\n{\ndecidewhichelementsshouldbedisplayed/omitted.\n{\nprovidefunctionsforhandlingnumbers/strings/booleans.\n\nProcessing:XSLTvs.XMLQuery\n{\nLongdebateonXMLdevelopmentlist:XQuery:ReinventingtheWheel?at\nhttp://lists.xml.org/archives/xml-dev/200102/msg00483.html\n{\nthesamepatternlanguage,i.e.XPath,andthesameexpressivepower.\n{\ndierentprocessingmodels.\n\nLinking:XSLTvs.XPointertheyshareXPathaslanguageforlocalizingfragmentsofXMLdocuments.\nTheplaceofXSLTintheXMLfamily(2/2)\nSimpleTransformationExampleswithXSLT\n\nXSLTracefromIBMAlphaWorksavailableat\nhttp://www.alphaworks.ibm.com/aw.nsf/download/xsltrace\n\nallowsausertovisually"stepthrough"anXSLtransformation,highlightingthetransformationrulesastheyare&#12;red.\n\nAddtheXSLTrace.jar,xml4j.jar,lotusxsl.jarJavaarchives$CLASSPATH.\n\ncommandline:javacom.ibm.xsl.xsltrace.XSLTrace&#xinpu;&#xt000;&#xstyl;î€€\n\ninput:xmlandxsltdocumentsfromChapters1and2fromXSLTProgrammer''sReference,M.Kay.\nhttp://www.wrox.com\nTheTransformationProcess\n\nbasedontemplaterules.\n\natemplaterule=templatepattern+templatebody.&#xxsl:;&#xtemp;&#xlate;&#x-105;&#x0000;match=''''pattern''''body&#x/xsl;&#x:tem;&#xplat;î€€thepatternmatchesnodesinthesourcetree.forthematchednodes,thetemplatebodyisinstantiated.\n\ntemplatepattern=XPathexpression.\n\ntemplatebody=literalresultelements+XSLTinstructions.\n\n&#12;ndtemplatesthatapplytonodesinthesourcetree.\n\nmoretemplatesforthesamenodes!processingmodesorcon\rictresolutionpolicy.\n\nnotemplatefornodes!built-intemplates.\n\nafterprocessinganode,starttoprocessitschildren:&#xxsl:;&#xappl;&#xy-te;&#xmpla;&#xtes0;\nPullProcessing\nHowisworking?\n\nexplicitlyselectandprocesstherequirednodes.&#xxsl:;&#xvalu;&#xe-of;&#x-105;&#x0000;select=''''pattern''''/&#xxsl:;&#xappl;&#xy-te;&#xmpla;&#xtes-;áselect=''''pattern''''/&#xxsl:;&#xfor-;&#xeach;&#x-105;&#x0000;select=''''pattern''''/\n\ngreatercontroloverwhichnodesaretobeprocessed.Application:verydierentstructureforinputandoutput.Example(Chapter1)\n\nXMLSource:books.xml\n\nXSLTStyleSheet:books_pull.xsl\nCon\rictResolutionPolicy\n\nmoretemplateswithpatternsmatchingthesamenodeinthesourcetree.\n\nnoprocessingmodesareused.\n\nappearswhenseveralstylesheetsareimported,orincluded.Solution:eachtemplatehasapriority\n\nsetbyanXSLTinstruction.match=''''pattern''''&#xxsl:;&#xtemp;&#xlate;&#x-105;&#x0000;priority=''''1''''/.\n\ngivenbytheselectivityofitspattern.\nPatterns\nDefaultpriority\nnode(),text(),*\n-0.5\nabc:*\n(-0.5,0.0)\ntitle,@id\n0.0\nbook[@isbn],para[1]\n&#x0000;0.0\nAnumericallyhighervalueindicatesahigherpriority.\nXSLTProcessors:Saxon\n\nopensource,availableat\nhttp://users.iclway.co.uk/mhkay/saxon/\n.\n\nrunsonJava1.1orJava2platform.\n\nInstalation\n{\nfetchinstant-saxon.ziporsaxon.zip.\n{\nsetCLASSPATHaccordingly:CLASSPATH=saxon.jar:$CLASSPATH.\n\nInvokation\n{\ncommandline:saxonsource.xmlstyle.xsl&#x0000;output.html\n{\nJavaapplication:viatheTrAXAPIde&#12;nedinJAXP1.1javacom.icl.saxon.StyleSheetsource.xmlstyle.xsl&#x0000;output.html\n\nbuilt-inextensionXPathfunctions:after(ns1,ns2),before(ns1,ns2),difference(ns1,ns2),intersection(ns1,ns2),distinct(ns1),evaluate(string).\n\nbuilt-inextensionXSLTelements:&#xsaxo;&#xn:fu;&#xncti;&#xon00;,&#xsaxo;&#xn:re;&#xturn;,&#xsaxo;&#xn:wh;&#xile0;.\nXSLTProcessors:Xalan\n\nopensource,availableat\nhttp://www.apache.org/\n.\n\nJavaandC++versions.\n\nInstalation\n{\nfetchxalan.jar,xerces.jar.\n{\nsetCLASSPATHaccordingly:CLASSPATH=xerces.jar:xalan.jar:$CLASSPATH.\n\nInvokation\n{\ncommandline:javaorg.apache.xalan.xslt.Process-ina.xml-xslb.xsl-outc.html\n\nuser-de&#12;nedandbuilt-inextensionfunctionsandelements.\n\nbuilt-inextensionfunctions:difference(ns1,ns2),intersection(ns1,ns2),distinct(ns1),evaluate(string).\n\nSQLextensionfunctionsforJDBCconnections.\n\nmultipleoutput&#12;les.\nXSLTProcessors:Architecture\nXSLTProcessors:Comparison\nWhat''scoming?XSLT2.0\nXSLT1.1standardizesasmallnumberofurgentfeatures.\n\nmultipleoutputdocumentsvia&#xxsl:;&#xdocu;&#xment;.\n\ntemporarytreesvianodeset().\n\nstandardbindingstoextensionfunctionswritteninJavaandECMAScript.XSLT2.0at\nhttp://www.w3.org/TR/xslt20req\n.\n\nsimplifymanipulationofXMLSchema-typedcontent.\n\nsupportforreverseIDREFattributes,e.g.key()function.\n\nsupportsortingnodesbasedonXMLSchematype.\n\nsimplifygrouping.\nTutorials:Usefullinks\n\nXSLTW3CSpeci&#12;cation\nhttp://www.w3c.org/TR/xslt\n\nXSLTProgrammer''sReference,SndEdition.MichaelKay.\nwww.wrox.com\n\nXSLTTutorialatZvon\nhttp://www.zvon.org/xxl/XSLTutorial/Output/index.html\n\nXSLTutorialatW3Schools\nhttp://www.w3schools.com/xsl/\n\nPracticaltransformationusingXSLTandXPath\nhttp://www-106.ibm.com/developerworks/education/xslt-xpath-tutorial.html\n\nTheXMLCoverPages\nhttp://xml.coverpages.org/xsl.html\n', 'Ankita@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`) VALUES
(4, 'times@gmail.com', 'c150111bafc331bafb353619452c5c5c'),
(3, 'tejas@gmail.com', '1ff0102a5b4c3fbcbe5269aabe953b0e'),
(5, 'chefK@gmail.com', '9a45a8691ed8bb1a4ff7039d33d54a7d'),
(6, 'chef@gmail.com', '9a45a8691ed8bb1a4ff7039d33d54a7d'),
(7, 'Ankita@gmail.com', 'de5b5bf65ba66517f9b70b1443d2102d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`doc_id`),
  ADD UNIQUE KEY `my_unique_key` (`doc_url`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
