<?php $con = mysqli_connect("localhost","root","","searchE");
if (!$con)
  {
  die('Could not connect: ' . mysqli_connect_error());
  }
  
 

?>