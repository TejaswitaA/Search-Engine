<?php
session_start();
include_once('config.php');

if($_SERVER['REQUEST_METHOD'] == "POST"){
 // Get data
 $email =  $_POST['email'];
 $password = md5($_POST['password']);
 
 // Insert data into data base
$query="SELECT user_name FROM users WHERE user_name='$email' LIMIT 1";

 $result = mysqli_query($con,$query);
   $num= mysqli_num_rows($result);
   if($num!=1)
		{	
		session_start();
		$_SESSION["mail"]=$email;
		$query1=mysqli_query($con,"INSERT INTO users(user_name, user_password) VALUES('$email','$password')");
				
			if(!$query1){
				die('error inserting new record') ;
			}	
			else
			{
				header("Location:admin.php");
			}
		}
	else {
		echo '<script>alert("User Already exists!!");</script>';
		header("refresh:0;url=signup.php");
	}
}
?>